import pygame
import random
import asyncio

pygame.init()

SCREENWIDTH = 1000
SCREENHEIGHT = 700
screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
clock = pygame.time.Clock()

player_x = 200
player_y = 100
player_movement = 0
gravity = 0.5
gamespeed = 3

score = 0

gameover = False
startgame = False
selectmodesc = False
normalmode = True
whbmode = False
hbmode = False

inpillar1 = False
inpillar2 = False
inpillar3 = False

playbutton = pygame.Rect(425, 275, 150, 150)
modescbutton = pygame.Rect(600, 300, 100, 100)
modescscreen = pygame.Rect(500, 400, 300, 300)
normalmodebutton = pygame.Rect(501, 401, 298, 98)
whbmodebutton = pygame.Rect(501, 501, 298, 98)
hbmodebutton = pygame.Rect(501, 601, 298, 98)

mainmenubutton = pygame.Rect(350, 300, 100, 100)
restartbutton = pygame.Rect(550, 300, 100, 100)

pillar1_x = 1100
pillar1_y = random.randint(250, 650)
pillar2_x = 1500
pillar2_y = random.randint(250, 650)
pillar3_x = 1900
pillar3_y = random.randint(250, 650)
cloud1_x = random.randint(250, 350)
cloud1_y = random.randint(0, 600)
cloud2_x = random.randint(600, 700)
cloud2_y = random.randint(0, 600)
cloud3_x = random.randint(900, 1000)
cloud3_y = random.randint(0, 600)
cloud4_x = random.randint(1200, 1300)
cloud4_y = random.randint(0, 600)

pillar1d = pygame.Rect(pillar1_x, pillar1_y, 75, 600)
pillar1u = pygame.Rect(pillar1_x, pillar1_y - 800, 75, 600)
pillar2d = pygame.Rect(pillar2_x, pillar2_y, 75, 600)
pillar2u = pygame.Rect(pillar2_x, pillar2_y - 800, 75, 600)
pillar3d = pygame.Rect(pillar3_x, pillar3_y, 75, 600)
pillar3u = pygame.Rect(pillar3_x, pillar3_y - 800, 75, 600)
player = pygame.Rect(player_x, player_y, 50, 50)

async def main():
    global player_y, player_movement, pillar1_x, pillar1_y, pillar2_x, pillar2_y, pillar3_x, pillar3_y, score, gameover, pillar1d, pillar1u, pillar2d, pillar2u, pillar3d, pillar3u, player, inpillar1, inpillar2, inpillar3, startgame, playbutton, modescbutton, modescscreen, selectmodesc, normalmode, whbmode, hbmode, normalmodebutton, whbmodebutton, hbmodebutton, gamespeed, mainmenubutton, restartbutton, cloud1_x, cloud1_y, cloud2_x, cloud2_y, cloud3_x, cloud3_y, cloud4_x, cloud4_y

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if not gameover and startgame:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        player_movement = -10

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if playbutton.collidepoint(event.pos):
                        startgame = True
                    
                if event.type == pygame.MOUSEBUTTONDOWN:
                    player_movement = -10

            if event.type == pygame.MOUSEBUTTONDOWN:
                if not selectmodesc:
                    if playbutton.collidepoint(event.pos):
                        startgame = True
                    if modescbutton.collidepoint(event.pos):
                        selectmodesc = True
                if selectmodesc:
                    if normalmodebutton.collidepoint(event.pos):
                        normalmode = True
                        whbmode = False
                        hbmode = False
                        selectmodesc = False
                    if whbmodebutton.collidepoint(event.pos):
                        whbmode = True
                        normalmode = False
                        hbmode = False
                        selectmodesc = False
                    if hbmodebutton.collidepoint(event.pos):
                        hbmode = True
                        normalmode = False
                        whbmode = False
                        selectmodesc = False
                if gameover:
                    if mainmenubutton.collidepoint(event.pos):
                        startgame = False
                        pillar1_x = 1100
                        pillar2_x = 1500
                        pillar3_x = 1900
                        player_y = 100
                        gameover = False
                        selectmodesc = False
                        score = 0
                    if restartbutton.collidepoint(event.pos):
                        pillar1_x = 1100
                        pillar2_x = 1500
                        pillar3_x = 1900
                        player_y = 100
                        gameover = False
                        startgame = True
                        selectmodesc = False
                        score = 0


        if not gameover and startgame:
            player_movement += gravity
            player_y += player_movement

        if player_y < 0:
            player_y = 0
            gameover = True
        if player_y > 650:
            player_y = 650
            gameover = True
        
        if not gameover and startgame:
            pillar1_x -= gamespeed
            pillar2_x -= gamespeed
            pillar3_x -= gamespeed
            
            if pillar1_x < -125:
                pillar1_x = 1100
                pillar1_y = random.randint(250, 650)
        
            if pillar2_x < -125:
                pillar2_x = 1100
                pillar2_y = random.randint(250, 650)
        
            if pillar3_x < -125:
                pillar3_x = 1100
                pillar3_y = random.randint(250, 650)
            if player_x == pillar1_x:
                score += 1
            if player_x == pillar2_x:
                score += 1
            if player_x == pillar3_x:
                score += 1
            if score == 1:
                score += 2

        if player_x - pillar1_x > -50 and player_x - pillar1_x < 25:
            inpillar1 = True
        else:
            inpillar1 = False
        if player_x - pillar2_x > -50 and player_x - pillar2_x < 25:
            inpillar2 = True
        else:
            inpillar2 = False
        if player_x - pillar3_x > -50 and player_x - pillar3_x < 25:
            inpillar3 = True
        else:
            inpillar3 = False

        if player_y + 50 > pillar1_y and inpillar1:
            gameover = True
        if player_y + 50 > pillar2_y and inpillar2:
            gameover = True
        if player_y + 50 > pillar3_y and inpillar3:
            gameover = True

        if player_y < pillar1_y - 200 and inpillar1:
            gameover = True
        if player_y < pillar2_y - 200 and inpillar2:
            gameover = True
        if player_y < pillar3_y - 200 and inpillar3:
            gameover = True
        
        screen.fill((135, 206, 235))

        cloudimg = pygame.image.load("download5.png").convert()
        cloudimg.set_colorkey((255, 255, 255))
        screen.blit(cloudimg, (cloud1_x, cloud1_y))
        screen.blit(cloudimg, (cloud2_x, cloud2_y))
        screen.blit(cloudimg, (cloud3_x, cloud3_y))
        screen.blit(cloudimg, (cloud4_x, cloud4_y))

        if startgame and not gameover:
            cloud1_x -= 1
            cloud2_x -= 1
            cloud3_x -= 1
            cloud4_x -= 1

        if cloud1_x == -250:
            cloud1_x = 1100
            cloud1_y = random.randint(0, 600)
        if cloud2_x == -250:
            cloud2_x = 1100
            cloud2_y = random.randint(0, 600)
        if cloud3_x == -250:
            cloud3_x = 1100
            cloud3_y = random.randint(0, 600)
        if cloud4_x == -250:
            cloud4_x = 1100
            cloud4_y = random.randint(0, 600)

        birdpng = pygame.image.load("download.png").convert()
        birdpng = pygame.transform.scale(birdpng, (100, 100))
        birdpng.set_colorkey((255, 255, 255))
        pillardpng = pygame.image.load("download1.png").convert()
        pillardpng.set_colorkey((255, 255, 255))
        pillarupng = pygame.image.load("download2.png").convert()
        pillarupng.set_colorkey((255, 255, 255))
        
        if whbmode or hbmode:
            pygame.draw.rect(screen, (200, 250, 0), (player_x, player_y, 50, 50))
            pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y, 75, 600))
            pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y - 800, 75, 600))
            pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y, 75, 600))
            pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y - 800, 75, 600))
            pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y, 75, 600))
            pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y - 800, 75, 600))
        if normalmode or whbmode:
             screen.blit(birdpng, (player_x - 10, player_y)) 
             screen.blit(pillardpng, (pillar1_x, pillar1_y)) 
             screen.blit(pillardpng, (pillar2_x, pillar2_y)) 
             screen.blit(pillardpng, (pillar3_x, pillar3_y)) 
             screen.blit(pillarupng, (pillar1_x, pillar1_y - 800)) 
             screen.blit(pillarupng, (pillar2_x, pillar2_y - 800)) 
             screen.blit(pillarupng, (pillar3_x, pillar3_y - 800)) 

        scorefont = pygame.font.SysFont(None, 50).render("score : "+str(score), None, (0, 0, 0))
        screen.blit(scorefont, (0, 0),)

        if not startgame:
            pygame.draw.rect(screen, (206, 0, 5), playbutton)
            playfont = pygame.font.SysFont(None, 100).render("play", None, (0, 0, 0))
            screen.blit(playfont, (430, 310))
            pygame.draw.rect(screen, (244, 0, 5), modescbutton)
            modescselectfont = pygame.font.SysFont(None, 50).render("mode", None, (0, 0, 0))
            screen.blit(modescselectfont, (605, 330))
            if selectmodesc == True:
                pygame.draw.rect(screen, (33, 147, 0), modescscreen)
                pygame.draw.rect(screen, (41, 185, 0), normalmodebutton)
                screen.blit(birdpng, (511, 425))
                normalmodefont = pygame.font.SysFont(None, 40).render("normal mode", None, (0, 0, 0))
                screen.blit(normalmodefont, (600, 440))
                pygame.draw.rect(screen, (41, 185, 0), whbmodebutton)
                pygame.draw.rect(screen, (200, 250, 0), (521, 525, 50, 50))
                screen.blit(birdpng, (511, 525))
                whbmodefont = pygame.font.SysFont(None, 40).render("whb mode", None, (0, 0, 0))
                screen.blit(whbmodefont, (600, 540))
                pygame.draw.rect(screen, (41, 185, 0), hbmodebutton)
                pygame.draw.rect(screen, (200, 250, 0), (521, 625, 50, 50))
                hbmodefont = pygame.font.SysFont(None, 40).render("hb mode", None, (0, 0, 0))
                screen.blit(hbmodefont, (600, 640))

        if gameover:
            gameoverfont = pygame.font.SysFont(None, 200).render("game over!", None, (0, 0, 0))
            mainmenufont = pygame.font.SysFont(None, 50).render("main menu", None, (0, 0, 0))
            restartfont = pygame.font.SysFont(None, 50).render("restart", None, (0, 0, 0))
            screen.blit(gameoverfont, (110, 100))
            screen.blit(mainmenufont, (310, 410))
            screen.blit(restartfont, (550, 410))
            mainmenubutpng = pygame.image.load("download3.png").convert()
            restartbutpng = pygame.image.load("download4.png").convert()
            screen.blit(mainmenubutpng, mainmenubutton)
            screen.blit(restartbutpng, restartbutton)

        if not startgame and not gameover:
            versionfont = pygame.font.SysFont(None, 50).render("version : 1", None, (0, 0, 0))
            screen.blit(versionfont, (0, 670))

        pygame.display.update()
        clock.tick(60)
        
        await asyncio.sleep(0)

asyncio.run(main())
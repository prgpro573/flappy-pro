import pygame
import random
import asyncio

pygame.init()

SCREENWIDTH = 1000
SCREENHEIGHT = 700
screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
clock = pygame.time.Clock()

player_x = 200
player_y = 350
player_movement = 0
gravity = 0.5
gamespeed = 3

pillar1_x = 1100
pillar1_y = random.randint(250, 650)
pillar2_x = 1500
pillar2_y = random.randint(250, 650)
pillar3_x = 1900
pillar3_y = random.randint(250, 650)

async def main():
    global player_y, player_movement, pillar1_x, pillar1_y, pillar2_x, pillar2_y, pillar3_x, pillar3_y

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player_movement = -10
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                player_movement = -10

        player_movement += gravity
        player_y += player_movement
        
        pillar1_x -= gamespeed
        pillar2_x -= gamespeed
        pillar3_x -= gamespeed

        if player_y < 0:
            player_y = 0
        if player_y > 650:
            player_y = 650

        if pillar1_x < -125:
            pillar1_x = 1100
            pillar1_y = random.randint(250, 650)

        if pillar2_x < -125:
            pillar2_x = 1100
            pillar2_y = random.randint(250, 650)

        if pillar3_x < -125:
            pillar3_x = 1100
            pillar3_y = random.randint(250, 650)
        
        screen.fill((135, 206, 235))
        
        pygame.draw.rect(screen, (200, 250, 0), (player_x, player_y, 50, 50))
        
        pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y - 800, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y - 800, 75, 600))

        pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y - 800, 75, 600))

        pygame.display.update()
        clock.tick(60)
        
        await asyncio.sleep(0)

asyncio.run(main())
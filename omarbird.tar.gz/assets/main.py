import pygame
import random
import asyncio

pygame.init()

SCREENWIDTH = 1000
SCREENHEIGHT = 700
screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
clock = pygame.time.Clock()

player_x = 200
player_y = 350
player_movement = 0
gravity = 0.5
gamespeed = 3

score = 0

gameover = False

inpillar1 = False
inpillar2 = False
inpillar3 = False

pillar1_x = 1100
pillar1_y = random.randint(250, 650)
pillar2_x = 1500
pillar2_y = random.randint(250, 650)
pillar3_x = 1900
pillar3_y = random.randint(250, 650)

pillar1d = pygame.Rect(pillar1_x, pillar1_y, 75, 600)
pillar1u = pygame.Rect(pillar1_x, pillar1_y - 800, 75, 600)
pillar2d = pygame.Rect(pillar2_x, pillar2_y, 75, 600)
pillar2u = pygame.Rect(pillar2_x, pillar2_y - 800, 75, 600)
pillar3d = pygame.Rect(pillar3_x, pillar3_y, 75, 600)
pillar3u = pygame.Rect(pillar3_x, pillar3_y - 800, 75, 600)
player = pygame.Rect(player_x, player_y, 50, 50)

async def main():
    global player_y, player_movement, pillar1_x, pillar1_y, pillar2_x, pillar2_y, pillar3_x, pillar3_y, score, gameover, pillar1d, pillar1u, pillar2d, pillar2u, pillar3d, pillar3u, player, inpillar1, inpillar2, inpillar3

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if not gameover:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        player_movement = -10
                    
                if event.type == pygame.MOUSEBUTTONDOWN:
                    player_movement = -10

        if not gameover:
            player_movement += gravity
            player_y += player_movement

        if player_y < 0:
            player_y = 0
            gameover = True
        if player_y > 650:
            player_y = 650
            gameover = True
        
        if not gameover:
            pillar1_x -= gamespeed
            pillar2_x -= gamespeed
            pillar3_x -= gamespeed
            
            if pillar1_x < -125:
                pillar1_x = 1100
                pillar1_y = random.randint(250, 650)
        
            if pillar2_x < -125:
                pillar2_x = 1100
                pillar2_y = random.randint(250, 650)
        
            if pillar3_x < -125:
                pillar3_x = 1100
                pillar3_y = random.randint(250, 650)
            if player_x == pillar1_x:
                score += 1
            if player_x == pillar2_x:
                score += 1
            if player_x == pillar3_x:
                score += 1

        if player_x - pillar1_x > -50 and player_x - pillar1_x < 25:
            inpillar1 = True
        else:
            inpillar1 = False
        if player_x - pillar2_x > -50 and player_x - pillar2_x < 25:
            inpillar2 = True
        else:
            inpillar2 = False
        if player_x - pillar3_x > -50 and player_x - pillar3_x < 25:
            inpillar3 = True
        else:
            inpillar3 = False

        if player_y + 50 > pillar1_y and inpillar1:
            gameover = True
        if player_y + 50 > pillar2_y and inpillar2:
            gameover = True
        if player_y + 50 > pillar3_y and inpillar3:
            gameover = True

        if player_y < pillar1_y - 200 and inpillar1:
            gameover = True
        if player_y < pillar2_y - 200 and inpillar2:
            gameover = True
        if player_y < pillar3_y - 200 and inpillar3:
            gameover = True
        
        screen.fill((135, 206, 235))
        
        pygame.draw.rect(screen, (200, 250, 0), (player_x, player_y, 50, 50))
        pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar1_x, pillar1_y - 800, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar2_x, pillar2_y - 800, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y, 75, 600))
        pygame.draw.rect(screen, (0, 200, 0), (pillar3_x, pillar3_y - 800, 75, 600))


        scorefont = pygame.font.SysFont(None, 50).render("score : "+str(score), None, (0, 0, 0))
        screen.blit(scorefont, (0, 0),)

        pygame.display.update()
        clock.tick(60)
        
        await asyncio.sleep(0)

asyncio.run(main())